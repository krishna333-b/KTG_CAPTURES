KTG CAPTURES — PHOTOGRAPHY PORTFOLIO

WHAT'S INCLUDED
- app.py: Streamlit portfolio website
- images/: all 10 photographs you uploaded
- requirements.txt: Python dependency

RUN LOCALLY
1. Install Python 3.9 or newer.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py
5. Your browser will open the portfolio website.

CUSTOMISE
- Instagram URL is set to https://www.instagram.com/ktg_captures/.
- Photo titles, descriptions and collection names are near the top of app.py in the `photos` list.
- Replace or add image files in the images folder and update the matching entries in `photos`.
